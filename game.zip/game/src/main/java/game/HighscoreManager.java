package game;

import java.io.*;
import java.util.*;

public class HighscoreManager {

    private ArrayList<Highscore> highscores;
    private String filename;

    public HighscoreManager(String filename) {
        this.filename = filename;
        highscores = new ArrayList<Highscore>();
    }

    public void loadScores() {
        try {
            File file = new File(filename);
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(":");
                String name = parts[0];
                int seconds = Integer.parseInt(parts[1]);
                highscores.add(new Highscore(name, seconds));
            }
            br.close();
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
        sortScores();
    }

    public void saveScores() {
        try {
            File file = new File(filename);

            BufferedWriter bw = new BufferedWriter(new FileWriter(file));
            for (Highscore score : highscores) {
                bw.write(score.getName() + ":" + score.getSeconds() + "\n");
            }
            bw.close();
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void addScore(String name, int seconds) {
        highscores.add(new Highscore(name, seconds));
        sortScores();
    }

    public ArrayList<Highscore> getHighscores() {
        return highscores;
    }

    private void sortScores() {
        Collections.sort(highscores);
    }

    public class Highscore implements Comparable<Highscore> {
        private String name;
        private int seconds;

        public Highscore(String name, int seconds) {
            this.name = name;
            this.seconds = seconds;
        }

        public String getName() {
            return name;
        }

        public int getSeconds() {
            return seconds;
        }

        public int compareTo(Highscore other) {
            if (this.seconds > other.seconds) {
                return -1;
            } else if (this.seconds < other.seconds) {
                return 1;
            } else {
                return 0;
            }
        }
    }

    public static void main(String[] args){
        HighscoreManager h = new HighscoreManager("highscores.txt");
//        h.addScore("Sharif", 3);
//        h.saveScores();

        h.loadScores();
        for (int i = 0; i < h.highscores.size(); i++) {
            HighscoreManager.Highscore score = h.highscores.get(i);
            System.out.println((i+1) + ". " + score.getName() + ": " + score.getSeconds() + " seconds");
        }

    }

}
